# AI Automation Assistant for Android

An intelligent Android automation app that uses machine learning to learn your task patterns and automate repetitive actions. The app watches you interact with applications, learns the patterns, and can then execute those tasks automatically.

## Features

- 🎯 **Pattern Recognition**: Uses ML to recognize UI elements and patterns on screen
- 🤖 **Smart Automation**: Learns from your actions and can replay them intelligently
- 🎮 **Floating Widget**: Easy-to-use overlay control for toggling modes
- 📊 **Local Storage**: All data stored securely on your device
- 🔄 **Background Operation**: Runs in the background without interrupting your workflow
- 📱 **Touch Automation**: Full touch gesture support (tap, swipe, long press, scroll)

## System Requirements

- Android 13 (API 33) or higher
- Android 14, 15, 16 supported
- Minimum 2GB RAM recommended
- ~50MB storage space

## Permissions Required

The app requires the following permissions:

1. **Overlay Permission**: To display the floating widget
2. **Accessibility Service**: To perform automated touch actions
3. **Screen Capture**: To analyze screen content for pattern recognition
4. **Notification Permission** (Android 13+): For service notifications

## How It Works

### 1. Learning Mode
- Activate learning mode from the floating widget
- Use your apps normally while the AI watches
- The app captures screen patterns and your interactions
- ML models learn the relationship between patterns and actions

### 2. Automation Mode
- Once patterns are learned, activate Auto Mode
- The AI recognizes familiar patterns on screen
- Automatically executes the learned actions
- You can override at any time by toggling Auto Mode off

### 3. Pattern Storage
- All learned patterns stored locally in Room database
- Uses TensorFlow Lite for on-device ML processing
- Patterns improve over time with more observations

## Building the APK

### Prerequisites

1. Install Android Studio (Hedgehog or later)
2. Install JDK 17
3. Android SDK with API 33-34

### Build Steps

1. **Clone or extract the project**
   ```bash
   cd AIAutomationAssistant
   ```

2. **Open in Android Studio**
   - File → Open → Select the AIAutomationAssistant folder
   - Wait for Gradle sync to complete

3. **Build the APK**
   
   **Option A: Using Android Studio**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - APK will be in `app/build/outputs/apk/debug/app-debug.apk`
   
   **Option B: Using Command Line**
   ```bash
   # For debug APK
   ./gradlew assembleDebug
   
   # For release APK (unsigned)
   ./gradlew assembleRelease
   ```

4. **Find your APK**
   - Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
   - Release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Signing the Release APK (Optional)

For production use, sign your APK:

```bash
# Generate keystore (one time)
keytool -genkey -v -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000

# Sign the APK
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore my-release-key.keystore app-release-unsigned.apk my-key-alias

# Align the APK
zipalign -v 4 app-release-unsigned.apk app-release.apk
```

## Installation

### Via ADB
```bash
adb install app-debug.apk
```

### Manual Installation
1. Transfer the APK to your Android device
2. Open the APK file
3. If prompted, enable "Install from Unknown Sources"
4. Follow the installation prompts

## Initial Setup

1. **Launch the App**
   - Open "AI Automation Assistant"

2. **Enable Accessibility Service**
   - Tap "Enable Accessibility Service"
   - Find "Automation Accessibility Service" in the list
   - Toggle it ON
   - Confirm the permission

3. **Start Automation**
   - Tap "Start Automation"
   - Grant Overlay Permission when prompted
   - Grant Screen Capture Permission when prompted
   - The floating widget will appear

4. **Position the Widget**
   - Drag the widget to your preferred location
   - You can minimize it with the "−" button

## Usage Guide

### Learning a Task

1. **Activate Learning Mode**
   - Tap "Learning: OFF" in the floating widget
   - Button turns green: "Learning: ON"

2. **Perform Your Task**
   - Open the target app
   - Perform the actions you want to automate
   - The AI is watching and learning your patterns

3. **Stop Learning**
   - Tap "Learning: ON" to deactivate
   - Patterns are saved automatically

### Running Automation

1. **Activate Auto Mode**
   - Make sure you're on the same screen where you learned the task
   - Tap "Auto: OFF" in the floating widget
   - Button turns blue: "Auto: ON"

2. **Let AI Work**
   - The AI will recognize patterns and execute actions
   - You can watch it work or minimize the app

3. **Override Anytime**
   - Tap "Auto: ON" to regain manual control
   - AI stops immediately

### Recording Patterns

- Use the "⏺ Record Pattern" button to save specific UI patterns
- Useful for creating reusable templates

## Architecture

### Core Components

1. **FloatingWidgetService**: Manages the overlay control widget
2. **ScreenCaptureService**: Captures screen content for analysis
3. **AutomationAccessibilityService**: Executes touch automation
4. **MLProcessingService**: Handles pattern recognition and automation logic
5. **PatternRecognitionManager**: ML-based pattern matching and learning
6. **Room Database**: Stores learned patterns, actions, and tasks

### Data Flow

```
Screen Capture → Feature Extraction → Pattern Recognition
                                              ↓
User Actions → Event Recording → Pattern Learning
                                              ↓
Pattern Match → Action Determination → Touch Automation
```

### ML Model

- Uses TensorFlow Lite for on-device inference
- Feature-based pattern matching with cosine similarity
- Stores pattern templates for quick matching
- Adaptive learning from user interactions

## Troubleshooting

### Widget Not Showing
- Check overlay permission in Settings → Apps → AI Automation Assistant
- Restart the app

### Automation Not Working
- Verify Accessibility Service is enabled
- Check that Auto Mode is ON
- Ensure you're on a familiar screen with learned patterns

### Learning Not Recording
- Make sure Learning Mode is ON (green button)
- Verify screen capture permission was granted
- Check storage space on device

### App Crashes
- Clear app data: Settings → Apps → AI Automation Assistant → Clear Data
- Reinstall the app
- Check Android version compatibility

## Privacy & Security

- **All data stays on your device** - no cloud syncing
- **No internet permission** - cannot transmit data
- **Local ML processing** - all AI runs on-device
- **User control** - you decide what to learn and automate
- **Open source** - code is available for review

## Known Limitations

- Cannot automate system apps by default
- Some apps may block accessibility automation
- Battery usage increases during active automation
- Complex multi-app workflows may require manual setup

## Future Enhancements

- [ ] Custom script editor for advanced users
- [ ] Task scheduling and triggers
- [ ] Export/import learned tasks
- [ ] Voice control integration
- [ ] Better pattern visualization
- [ ] Multi-language support

## Technical Details

### Dependencies
- Kotlin 1.9.20
- TensorFlow Lite 2.14.0
- AndroidX Core & Lifecycle
- Room Database 2.6.1
- Coroutines for async operations

### Minimum SDK: API 33 (Android 13)
### Target SDK: API 34 (Android 14)

## License

This project is provided as-is for educational and personal use.

## Support

For issues or questions:
1. Check the Troubleshooting section
2. Review the usage guide
3. Check Android permissions and settings

## Contributing

Contributions welcome! Areas for improvement:
- Enhanced ML models
- Better UI/UX
- Additional automation features
- Bug fixes and optimizations

## Disclaimer

This app is for legitimate automation purposes only. Users are responsible for:
- Respecting app terms of service
- Following local laws and regulations
- Not using for unauthorized access or malicious purposes
- Understanding that some apps may detect and block automation

Use responsibly and ethically.

---

**Version**: 1.0  
**Last Updated**: February 2026  
**Compatible**: Android 13-16
