# Step-by-Step Build Guide for AI Automation Assistant

This guide will walk you through building the APK file from source code, even if you've never built an Android app before.

## What You Need

### Required Software

1. **Android Studio** (Free)
   - Download from: https://developer.android.com/studio
   - Version: Hedgehog (2023.1.1) or later
   - Size: ~1GB download, ~4GB installed

2. **Java Development Kit (JDK) 17**
   - Usually bundled with Android Studio
   - If needed separately: https://adoptium.net/

3. **Android SDK**
   - Automatically installed with Android Studio
   - Includes build tools and platforms

### System Requirements

- **Windows**: Windows 10/11 (64-bit)
- **Mac**: macOS 10.14 or later
- **Linux**: 64-bit distribution
- **RAM**: 8GB minimum, 16GB recommended
- **Disk Space**: 10GB free space

## Installation Steps

### Step 1: Install Android Studio

1. **Download Android Studio**
   - Visit: https://developer.android.com/studio
   - Click "Download Android Studio"
   - Accept the terms and download

2. **Install Android Studio**
   
   **Windows:**
   - Run the `.exe` installer
   - Follow the wizard (use default settings)
   - Allow it to download SDK components
   
   **Mac:**
   - Open the `.dmg` file
   - Drag Android Studio to Applications
   - Launch and follow setup wizard
   
   **Linux:**
   - Extract the `.tar.gz` file
   - Run `studio.sh` from the `bin/` directory
   - Follow setup wizard

3. **Complete First Run Setup**
   - Choose "Standard" installation type
   - Select your preferred theme
   - Let it download SDK components (this may take 10-30 minutes)
   - Click "Finish" when done

### Step 2: Prepare the Project

1. **Extract Project Files**
   - Locate the `AIAutomationAssistant` folder
   - Extract it to a location like:
     - Windows: `C:\AndroidProjects\AIAutomationAssistant`
     - Mac/Linux: `~/AndroidProjects/AIAutomationAssistant`

2. **Check Project Structure**
   ```
   AIAutomationAssistant/
   ├── app/
   │   ├── build.gradle
   │   ├── src/
   │   └── proguard-rules.pro
   ├── build.gradle
   ├── settings.gradle
   ├── gradle.properties
   └── README.md
   ```

### Step 3: Open Project in Android Studio

1. **Launch Android Studio**

2. **Open Project**
   - Click "Open" on the welcome screen
   - OR: File → Open
   - Navigate to your `AIAutomationAssistant` folder
   - Click "OK"

3. **Wait for Gradle Sync**
   - Android Studio will sync the project
   - This downloads dependencies (first time: 5-15 minutes)
   - Watch the progress bar at the bottom
   - Wait until you see "Gradle sync finished" in the status bar

4. **Troubleshooting Sync Issues**
   
   **If sync fails:**
   - Click "Try Again" button
   - OR: File → Sync Project with Gradle Files
   
   **If you see SDK errors:**
   - File → Project Structure → SDK Location
   - Make sure Android SDK location is set
   - Should be something like:
     - Windows: `C:\Users\YourName\AppData\Local\Android\Sdk`
     - Mac: `/Users/YourName/Library/Android/sdk`
     - Linux: `/home/YourName/Android/Sdk`

### Step 4: Build the APK

#### Method A: Using Menu (Recommended for Beginners)

1. **Select Build Variant**
   - View → Tool Windows → Build Variants
   - In the "Build Variants" panel, select "debug" or "release"
   - Debug: For testing, quicker build
   - Release: For distribution, optimized

2. **Build APK**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Wait for build to complete (1-5 minutes first time)
   - You'll see a notification when done

3. **Locate APK**
   - Click "locate" in the notification
   - OR: Navigate to `app/build/outputs/apk/debug/`
   - File name: `app-debug.apk`

#### Method B: Using Terminal/Command Line

1. **Open Terminal in Android Studio**
   - View → Tool Windows → Terminal
   - OR: Use system terminal and navigate to project folder

2. **Build Commands**
   
   **For Debug APK:**
   ```bash
   # Windows
   gradlew.bat assembleDebug
   
   # Mac/Linux
   ./gradlew assembleDebug
   ```
   
   **For Release APK:**
   ```bash
   # Windows
   gradlew.bat assembleRelease
   
   # Mac/Linux
   ./gradlew assembleRelease
   ```

3. **Wait for Build**
   - First build: 2-5 minutes
   - Subsequent builds: 30 seconds - 2 minutes

4. **Find APK**
   - Debug: `app/build/outputs/apk/debug/app-debug.apk`
   - Release: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Step 5: Sign Release APK (Optional)

Only needed for release builds you want to distribute.

1. **Generate Signing Key** (One Time Setup)
   
   In Android Studio Terminal:
   ```bash
   keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key-alias
   ```
   
   You'll be asked for:
   - Password (remember this!)
   - Name and organization details
   - Confirmation

2. **Sign the APK**
   
   Build → Generate Signed Bundle / APK → APK
   - Click "Create new..."
   - Fill in:
     - Key store path: Browse to `my-release-key.jks`
     - Password: Your keystore password
     - Alias: my-key-alias
     - Key password: Your key password
   - Click "Next"
   - Select "release" build variant
   - Check "V1 (Jar Signature)" and "V2 (Full APK Signature)"
   - Click "Finish"

3. **Find Signed APK**
   - Located in: `app/release/app-release.apk`

## Common Build Issues and Solutions

### Issue: Gradle Sync Failed

**Solution:**
1. Check internet connection
2. File → Invalidate Caches / Restart
3. Try: Tools → SDK Manager → SDK Tools
   - Check "Android SDK Build-Tools"
   - Click "Apply"

### Issue: SDK Not Found

**Solution:**
1. File → Project Structure
2. SDK Location tab
3. Set Android SDK location
4. Click "Apply"

### Issue: Kotlin Plugin Error

**Solution:**
1. File → Settings → Plugins
2. Search "Kotlin"
3. Install/Update Kotlin plugin
4. Restart Android Studio

### Issue: Out of Memory

**Solution:**
1. File → Settings → Build, Execution, Deployment → Compiler
2. Increase "Maximum heap size" to 2048 MB or more
3. OR edit `gradle.properties`:
   ```
   org.gradle.jvmargs=-Xmx4096m
   ```

### Issue: Build Takes Too Long

**Solution:**
1. File → Settings → Build, Execution, Deployment → Gradle
2. Check "Offline work" (if you have dependencies cached)
3. Increase "Maximum heap size"

## Installing APK on Your Device

### Method 1: USB Cable (ADB)

1. **Enable Developer Options on Phone**
   - Settings → About Phone
   - Tap "Build Number" 7 times
   - Go back, find "Developer Options"

2. **Enable USB Debugging**
   - Settings → Developer Options
   - Enable "USB Debugging"

3. **Connect Phone**
   - Plug in USB cable
   - On phone: Tap "Allow USB Debugging"

4. **Install APK**
   ```bash
   # In Android Studio Terminal
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

### Method 2: Direct Transfer

1. **Transfer APK to Phone**
   - USB: Copy APK file to Downloads folder
   - OR: Email APK to yourself
   - OR: Use Google Drive/Dropbox

2. **Enable Unknown Sources**
   - Settings → Security
   - Enable "Install unknown apps"
   - Select your file manager/browser

3. **Install**
   - Open file manager
   - Tap the APK file
   - Tap "Install"
   - Wait for completion

## Verification

### Check APK is Valid

1. **File Size**
   - Should be 10-20 MB
   - If less than 1 MB, build failed

2. **APK Analyzer**
   - Build → Analyze APK
   - Select your APK
   - Check classes.dex exists
   - Check resources exist

### Test Installation

1. Install on test device first
2. Grant all requested permissions
3. Open app and check:
   - Main screen loads
   - Buttons work
   - Can navigate to accessibility settings

## Next Steps

After building the APK:

1. **Read README.md** for usage instructions
2. **Test on your device** thoroughly
3. **Review permissions** before deployment
4. **Keep your signing key safe** (for updates)

## Build Optimization Tips

### Speed Up Builds

1. **Enable Parallel Builds**
   ```properties
   # In gradle.properties
   org.gradle.parallel=true
   org.gradle.caching=true
   ```

2. **Increase Memory**
   ```properties
   org.gradle.jvmargs=-Xmx4096m -XX:MaxPermSize=512m
   ```

3. **Use Offline Mode** (after first successful build)
   - File → Settings → Build, Execution, Deployment → Gradle
   - Check "Offline work"

### Reduce APK Size

1. **Enable Minification**
   - Already configured in `build.gradle`
   - Uses ProGuard to remove unused code

2. **Enable Resource Shrinking**
   ```gradle
   android {
       buildTypes {
           release {
               minifyEnabled true
               shrinkResources true
           }
       }
   }
   ```

## Getting Help

If you encounter issues:

1. **Check Error Messages**
   - Read the full error in Build Output
   - Google the specific error message

2. **Clean and Rebuild**
   - Build → Clean Project
   - Build → Rebuild Project

3. **Update Android Studio**
   - Help → Check for Updates

4. **Check Android Developer Docs**
   - https://developer.android.com/studio/build

## Conclusion

You should now have a working APK file ready to install on Android 13+ devices!

**Final Checklist:**
- [ ] Android Studio installed
- [ ] Project opened and synced
- [ ] APK built successfully
- [ ] APK file located
- [ ] (Optional) APK signed
- [ ] Ready to install on device

Happy automating! 🤖
