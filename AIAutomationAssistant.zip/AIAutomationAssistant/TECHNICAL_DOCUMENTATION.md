# Technical Documentation - AI Automation Assistant

## Architecture Overview

The AI Automation Assistant follows a modular architecture with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────┐
│                    User Interface Layer                 │
│  - MainActivity (Permission & Setup)                     │
│  - FloatingWidget (Overlay Controls)                     │
└──────────────────┬──────────────────────────────────────┘
                   │
┌──────────────────┴──────────────────────────────────────┐
│                   Service Layer                          │
│  - FloatingWidgetService (UI Overlay)                    │
│  - ScreenCaptureService (Screen Recording)               │
│  - MLProcessingService (Pattern Recognition)             │
│  - AutomationAccessibilityService (Touch Automation)     │
└──────────────────┬──────────────────────────────────────┘
                   │
┌──────────────────┴──────────────────────────────────────┐
│                 Business Logic Layer                     │
│  - PatternRecognitionManager (ML Processing)             │
│  - ImagePreprocessor (Feature Extraction)                │
└──────────────────┬──────────────────────────────────────┘
                   │
┌──────────────────┴──────────────────────────────────────┐
│                   Data Layer                             │
│  - Room Database (Local Storage)                         │
│  - DAOs (Data Access Objects)                            │
│  - Entities (Data Models)                                │
└─────────────────────────────────────────────────────────┘
```

## Core Components

### 1. MainActivity

**Purpose**: Entry point, permission management, service initialization

**Key Responsibilities:**
- Request and verify permissions (overlay, accessibility, notifications)
- Initialize and start foreground services
- Display service status
- Provide navigation to system settings

**Important Methods:**
- `checkPermissions()`: Validates all required permissions
- `startAutomation()`: Initiates the automation workflow
- `requestScreenCapturePermission()`: Gets MediaProjection permission

**Lifecycle:**
```
onCreate() → checkPermissions() → [User grants permissions] → startAutomation()
    → requestScreenCapturePermission() → [Service starts]
```

### 2. FloatingWidgetService

**Purpose**: Manages the overlay widget for user control

**Key Features:**
- Draggable floating widget
- Real-time mode switching (Learning/Auto)
- Foreground service with persistent notification
- Service lifecycle management

**State Management:**
```kotlin
private var isLearningMode = false
private var isAutoMode = false
```

**Communication:**
- Starts/stops other services via Intents
- Updates UI based on service states
- Receives user input from widget buttons

### 3. ScreenCaptureService

**Purpose**: Captures screen content for ML analysis

**Technical Details:**
- Uses MediaProjection API for screen recording
- Creates VirtualDisplay for rendering
- ImageReader for frame capture
- Captures at 500ms intervals (configurable)

**Frame Processing Pipeline:**
```
VirtualDisplay → ImageReader → acquireLatestImage() → imageToBitmap()
    → PatternRecognitionManager.processFrame()
```

**Performance Considerations:**
- Bitmap recycling to prevent memory leaks
- Configurable capture interval
- Automatic cleanup on service destroy

### 4. AutomationAccessibilityService

**Purpose**: Execute automated touch gestures

**Capabilities:**
- Click: Single tap at coordinates
- Swipe: Directional gestures
- Long Press: Extended tap duration
- Scroll: Directional scrolling
- Text Input: Type into focused fields
- System Actions: Back, Home, Recents, Notifications

**Gesture API:**
```kotlin
suspend fun performClick(x: Float, y: Float): Boolean
suspend fun performSwipe(startX, startY, endX, endY, duration): Boolean
suspend fun performLongPress(x: Float, y: Float, duration: Long): Boolean
suspend fun performScroll(direction: ScrollDirection, amount: Float): Boolean
```

**Event Recording:**
- Monitors accessibility events during learning mode
- Records user interactions for pattern learning
- Correlates events with screen captures

### 5. MLProcessingService

**Purpose**: Orchestrate pattern recognition and automation execution

**Operating Modes:**
```kotlin
enum class ProcessingMode {
    IDLE,      // No active processing
    LEARNING,  // Recording user actions
    AUTOMATION // Executing learned tasks
}
```

**Learning Mode Workflow:**
```
1. Receive screen frames from ScreenCaptureService
2. Extract features from frames
3. Record user actions from AccessibilityService
4. Build action sequences
5. Store patterns in database
6. Update ML model
```

**Automation Mode Workflow:**
```
1. Capture current screen state
2. Recognize patterns in screenshot
3. Match against learned patterns
4. Determine next action
5. Execute via AccessibilityService
6. Wait and repeat
```

### 6. PatternRecognitionManager

**Purpose**: ML-based pattern detection and matching

**Feature Extraction:**
- Downsamples images to 224x224
- Converts to normalized RGB feature vectors
- Creates 150,528-dimension feature space (224 × 224 × 3)

**Pattern Matching:**
- Cosine similarity for feature comparison
- Threshold: 0.8 (80% similarity)
- Template-based matching for known patterns

**Learning Algorithm:**
```
1. Extract features from screen frame
2. Compare with existing pattern templates
3. If match found (>75% similarity):
   - Increment observation count
   - Update last seen timestamp
4. If no match:
   - Create new pattern template
   - Add to template database
```

**Optimization:**
- Feature caching for repeated frames
- Template pruning for old/unused patterns
- Adaptive thresholds based on observation count

## Data Models

### ActionSequence

Stores individual actions performed by the user:

```kotlin
data class ActionSequence(
    val actionType: String,     // CLICK, SWIPE, etc.
    val x: Float?,              // Touch coordinates
    val y: Float?,
    val sequenceId: String,     // Groups related actions
    val orderInSequence: Int,   // Order within group
    val timestamp: Long,
    val confidence: Float,      // Prediction confidence
    val successRate: Float,     // Historical success rate
    val executionCount: Int     // Times executed
)
```

### RecognizedPattern

Represents UI patterns detected on screen:

```kotlin
data class RecognizedPattern(
    val patternType: String,    // BUTTON, TEXT_FIELD, etc.
    val confidence: Float,      // Recognition confidence
    val x: Float, y: Float,     // Location
    val width: Int, height: Int, // Dimensions
    val features: String?,      // Feature vector JSON
    val visualHash: String?     // Visual signature
)
```

### LearnedTask

High-level task/workflow:

```kotlin
data class LearnedTask(
    val taskName: String,
    val sequenceId: String,     // Links to ActionSequence
    val triggerPattern: String?, // Pattern that starts task
    val useCount: Int,          // Usage statistics
    val isEnabled: Boolean,     // Can be disabled
    val priority: Int           // Execution priority
)
```

## Database Schema

```sql
-- action_sequences table
CREATE TABLE action_sequences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actionType TEXT NOT NULL,
    x REAL,
    y REAL,
    endX REAL,
    endY REAL,
    direction TEXT,
    text TEXT,
    duration INTEGER,
    sequenceId TEXT NOT NULL,
    orderInSequence INTEGER NOT NULL,
    timestamp INTEGER NOT NULL,
    appPackageName TEXT,
    screenContext TEXT,
    confidence REAL DEFAULT 1.0,
    successRate REAL DEFAULT 1.0,
    executionCount INTEGER DEFAULT 0
);

-- recognized_patterns table
CREATE TABLE recognized_patterns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patternType TEXT NOT NULL,
    confidence REAL NOT NULL,
    x REAL NOT NULL,
    y REAL NOT NULL,
    width INTEGER NOT NULL,
    height INTEGER NOT NULL,
    features TEXT,
    visualHash TEXT,
    timestamp INTEGER NOT NULL,
    appPackageName TEXT,
    screenId TEXT
);

-- learned_tasks table
CREATE TABLE learned_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    taskName TEXT NOT NULL,
    description TEXT,
    sequenceId TEXT NOT NULL,
    triggerPattern TEXT,
    createdAt INTEGER NOT NULL,
    lastUsed INTEGER,
    useCount INTEGER DEFAULT 0,
    isEnabled INTEGER DEFAULT 1,
    priority INTEGER DEFAULT 0
);
```

## Machine Learning Pipeline

### 1. Feature Extraction

```kotlin
fun extractFeatures(bitmap: Bitmap): FloatArray {
    // Resize to standard dimensions
    val scaledBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
    
    // Convert pixels to normalized float array
    val features = FloatArray(224 * 224 * 3)
    for (y in 0 until 224) {
        for (x in 0 until 224) {
            val pixel = scaledBitmap.getPixel(x, y)
            features[index++] = ((pixel shr 16) and 0xFF) / 255f  // R
            features[index++] = ((pixel shr 8) and 0xFF) / 255f   // G
            features[index++] = (pixel and 0xFF) / 255f           // B
        }
    }
    return features
}
```

### 2. Similarity Calculation

```kotlin
fun calculateSimilarity(features1: FloatArray, features2: FloatArray): Float {
    // Cosine similarity: dot(A,B) / (||A|| * ||B||)
    var dotProduct = 0f
    var norm1 = 0f
    var norm2 = 0f
    
    for (i in features1.indices) {
        dotProduct += features1[i] * features2[i]
        norm1 += features1[i] * features1[i]
        norm2 += features2[i] * features2[i]
    }
    
    return dotProduct / sqrt(norm1 * norm2)
}
```

### 3. Pattern Matching

```kotlin
suspend fun recognizePatterns(bitmap: Bitmap): List<RecognizedPattern> {
    val features = extractFeatures(bitmap)
    val patterns = mutableListOf<RecognizedPattern>()
    
    patternTemplates.forEach { template ->
        val similarity = calculateSimilarity(features, template.features)
        
        if (similarity > 0.8f) {  // Threshold
            patterns.add(RecognizedPattern(
                patternType = template.type,
                confidence = similarity,
                x = template.x,
                y = template.y,
                // ... other fields
            ))
        }
    }
    
    return patterns
}
```

## Extending the Application

### Adding New Action Types

1. **Define Action Type**
   ```kotlin
   // In ActionSequence
   const val ACTION_PINCH = "PINCH"
   const val ACTION_ROTATE = "ROTATE"
   ```

2. **Implement in AccessibilityService**
   ```kotlin
   suspend fun performPinch(
       centerX: Float,
       centerY: Float,
       startDistance: Float,
       endDistance: Float
   ): Boolean {
       // Implementation using GestureDescription
   }
   ```

3. **Add to MLProcessingService**
   ```kotlin
   when (action.actionType) {
       "PINCH" -> accessibilityService.performPinch(...)
       // ... other cases
   }
   ```

### Integrating Custom ML Models

Replace the feature-based matching with TensorFlow Lite:

```kotlin
class PatternRecognitionManager(context: Context) {
    private var interpreter: Interpreter? = null
    
    init {
        val model = FileUtil.loadMappedFile(context, "custom_model.tflite")
        interpreter = Interpreter(model)
    }
    
    fun runInference(bitmap: Bitmap): FloatArray {
        val input = preprocessImage(bitmap)
        val output = Array(1) { FloatArray(OUTPUT_SIZE) }
        
        interpreter?.run(input, output)
        return output[0]
    }
}
```

### Adding Task Triggers

Implement pattern-based task triggering:

```kotlin
class TaskTriggerManager(
    private val database: AppDatabase,
    private val patternRecognition: PatternRecognitionManager
) {
    suspend fun checkTriggers(screenshot: Bitmap): LearnedTask? {
        val patterns = patternRecognition.recognizePatterns(screenshot)
        val tasks = database.learnedTaskDao().getEnabledTasks()
        
        for (task in tasks) {
            if (matchesTriggerPattern(patterns, task.triggerPattern)) {
                return task
            }
        }
        return null
    }
}
```

### Implementing Task Scheduling

Add time-based or event-based task execution:

```kotlin
class TaskScheduler(private val context: Context) {
    fun scheduleTask(task: LearnedTask, trigger: Trigger) {
        val workRequest = when (trigger) {
            is TimeTrigger -> PeriodicWorkRequest.Builder(
                TaskExecutionWorker::class.java,
                trigger.interval,
                TimeUnit.MINUTES
            ).build()
            
            is EventTrigger -> OneTimeWorkRequest.Builder(
                TaskExecutionWorker::class.java
            ).setConstraints(trigger.constraints).build()
        }
        
        WorkManager.getInstance(context).enqueue(workRequest)
    }
}
```

## Performance Optimization

### Memory Management

1. **Bitmap Recycling**
   ```kotlin
   bitmap.recycle()  // Free bitmap memory
   ```

2. **Weak References for Caches**
   ```kotlin
   private val featureCache = WeakHashMap<String, FloatArray>()
   ```

3. **Limit Database Size**
   ```kotlin
   // Delete old patterns
   dao.deleteOldPatterns(System.currentTimeMillis() - 30.days)
   ```

### Battery Optimization

1. **Adaptive Capture Intervals**
   ```kotlin
   val interval = if (isAutoMode) 500L else 2000L
   ```

2. **Doze Mode Exemption**
   ```kotlin
   val powerManager = getSystemService(PowerManager::class.java)
   val packageName = packageName
   
   if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
       // Request exemption
   }
   ```

### CPU Usage

1. **Offload to Background Threads**
   ```kotlin
   withContext(Dispatchers.Default) {
       // CPU-intensive work
   }
   ```

2. **Throttle Processing**
   ```kotlin
   val lastProcessed = AtomicLong(0)
   if (System.currentTimeMillis() - lastProcessed.get() < MIN_INTERVAL) {
       return  // Skip this frame
   }
   ```

## Security Considerations

### Permission Model

- All permissions requested with clear explanations
- Runtime permission checks before each sensitive operation
- Graceful degradation if permissions denied

### Data Privacy

- No internet permission → data cannot leave device
- No analytics or tracking
- User controls all data collection
- Clear data option in settings

### Secure Storage

```kotlin
// Encrypt sensitive data before storing
val encryptedData = EncryptionUtils.encrypt(sensitiveData)
preferences.edit().putString("key", encryptedData).apply()
```

## Testing

### Unit Tests

```kotlin
@Test
fun testPatternMatching() {
    val manager = PatternRecognitionManager(context)
    val features1 = FloatArray(100) { 0.5f }
    val features2 = FloatArray(100) { 0.5f }
    
    val similarity = manager.calculateSimilarity(features1, features2)
    assertEquals(1.0f, similarity, 0.01f)
}
```

### Integration Tests

```kotlin
@Test
fun testAutomationWorkflow() {
    // Start services
    val intent = Intent(context, FloatingWidgetService::class.java)
    context.startService(intent)
    
    // Verify service running
    assertTrue(FloatingWidgetService.isRunning)
    
    // Stop services
    context.stopService(intent)
}
```

### UI Tests

```kotlin
@Test
fun testFloatingWidget() {
    val scenario = ActivityScenario.launch(MainActivity::class.java)
    
    onView(withId(R.id.btnStartAutomation)).perform(click())
    
    // Verify widget shown
    onView(withId(R.id.widgetHeader)).check(matches(isDisplayed()))
}
```

## Debugging

### Enable Logging

```kotlin
companion object {
    private const val TAG = "AutomationService"
    private const val DEBUG = BuildConfig.DEBUG
}

if (DEBUG) {
    Log.d(TAG, "Processing frame: ${bitmap.width}x${bitmap.height}")
}
```

### ADB Commands

```bash
# View logs
adb logcat | grep "Automation"

# Clear app data
adb shell pm clear com.aiautomation.assistant

# Check service status
adb shell dumpsys activity services com.aiautomation.assistant

# Force stop
adb shell am force-stop com.aiautomation.assistant
```

## Deployment Checklist

- [ ] Update version code and name in `build.gradle`
- [ ] Test on multiple Android versions (13, 14, 15, 16)
- [ ] Test on different screen sizes
- [ ] Verify all permissions work correctly
- [ ] Test battery usage over extended period
- [ ] Ensure proper cleanup on service stop
- [ ] Generate signed release APK
- [ ] Create changelog
- [ ] Update README with any new features

## Future Architecture Improvements

1. **Modularization**: Split into feature modules
2. **Dependency Injection**: Use Hilt for cleaner architecture
3. **Repository Pattern**: Abstract data sources
4. **ViewModel**: Separate UI logic from lifecycle
5. **Compose UI**: Modern declarative UI framework
6. **Cloud Sync**: Optional encrypted backup

## Conclusion

This architecture provides a solid foundation for AI-powered automation while maintaining:
- Clear separation of concerns
- Testability
- Extensibility
- Performance
- Security
- User privacy

For questions or contributions, refer to the main README.md.
