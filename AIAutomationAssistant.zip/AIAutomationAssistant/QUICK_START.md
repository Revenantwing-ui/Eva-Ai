# Quick Start Guide - AI Automation Assistant

## 🚀 Fastest Way to Get Started

### For Users (Just Want to Install)

**If you have the APK already:**
1. Transfer APK to your Android device
2. Open the APK file
3. Enable "Install from Unknown Sources" if prompted
4. Install the app
5. Open app and follow permission prompts
6. Done! Skip to "Using the App" below

**If you need to build the APK:**
→ See "For Builders" section below

---

### For Builders (Need to Create APK)

**Option 1: Android Studio (Recommended)**
1. Install Android Studio from: https://developer.android.com/studio
2. Open the `AIAutomationAssistant` folder in Android Studio
3. Wait for Gradle sync to finish
4. Click: Build → Build Bundle(s) / APK(s) → Build APK(s)
5. Find APK in: `app/build/outputs/apk/debug/app-debug.apk`

**Option 2: Command Line**
```bash
cd AIAutomationAssistant
./gradlew assembleDebug    # Mac/Linux
gradlew.bat assembleDebug  # Windows
```

**Need detailed help?** → See `BUILD_GUIDE.md`

---

### For Developers (Want to Customize)

**Architecture Overview:**
- MainActivity: Entry point, permissions
- FloatingWidgetService: Overlay UI controller
- ScreenCaptureService: Captures screen frames
- AutomationAccessibilityService: Performs touch actions
- MLProcessingService: Pattern recognition and automation
- PatternRecognitionManager: ML engine

**Key Files to Modify:**
- `MainActivity.kt` - Change UI or permission flow
- `FloatingWidgetService.kt` - Modify widget behavior
- `PatternRecognitionManager.kt` - Adjust ML algorithm
- `res/layout/*.xml` - Change UI appearance

**Full technical docs:** → See `TECHNICAL_DOCUMENTATION.md`

---

## 📱 Using the App

### First Time Setup (5 minutes)

1. **Install the app**
   - Open the installed app

2. **Grant Permissions**
   - Tap "Enable Accessibility Service"
   - Find "Automation Accessibility Service" in list
   - Toggle ON → Confirm

3. **Start Automation**
   - Tap "Start Automation"
   - Allow Overlay permission
   - Allow Screen Capture
   - Floating widget appears!

### Learning a Task (2 minutes)

1. **Activate Learning**
   - Tap "Learning: OFF" in floating widget
   - Button turns GREEN

2. **Perform Your Task**
   - Open any app
   - Do the actions you want to automate
   - App is watching and learning

3. **Stop Learning**
   - Tap "Learning: ON" (now green)
   - Pattern is saved!

### Running Automation (30 seconds)

1. **Go to Same Screen**
   - Open the app where you learned the task

2. **Activate Auto Mode**
   - Tap "Auto: OFF" in floating widget
   - Button turns BLUE

3. **Watch It Work**
   - AI recognizes patterns
   - Executes learned actions
   - Tap "Auto: ON" to stop anytime

---

## 🎯 Quick Tips

### Widget Controls
- **Drag header** to move widget
- **"−" button** to minimize
- **"×" button** to stop service
- **Green button** = Learning Mode
- **Blue button** = Auto Mode

### Best Practices
- Learn tasks in the same app
- Keep actions simple at first
- Stop learning when done
- Test auto mode carefully
- Can override anytime

### Common Issues
- **Widget not showing**: Check overlay permission
- **Auto not working**: Enable accessibility service
- **Learning not recording**: Check screen capture permission

---

## 📂 Project Structure

```
AIAutomationAssistant/
├── README.md                      ← Full user guide
├── BUILD_GUIDE.md                 ← Detailed build steps
├── TECHNICAL_DOCUMENTATION.md     ← Developer reference
├── PROJECT_SUMMARY.md             ← Project overview
├── QUICK_START.md                 ← This file
│
├── app/src/main/
│   ├── java/.../                  ← All Kotlin source code
│   ├── res/                       ← All UI layouts & resources
│   └── AndroidManifest.xml        ← App configuration
│
├── build.gradle                   ← Project build config
└── app/build.gradle              ← App dependencies
```

---

## 📚 Where to Find More Info

| If you want to...              | Read this file                    |
|-------------------------------|-----------------------------------|
| Install and use the app       | README.md                        |
| Build the APK from source     | BUILD_GUIDE.md                   |
| Understand the architecture   | TECHNICAL_DOCUMENTATION.md       |
| Get a project overview        | PROJECT_SUMMARY.md              |
| Quick reference               | QUICK_START.md (this file)      |

---

## ⚡ Common Commands

### Building
```bash
# Debug APK (for testing)
./gradlew assembleDebug

# Release APK (for distribution)
./gradlew assembleRelease

# Clean build
./gradlew clean assembleDebug
```

### Installing
```bash
# Via ADB
adb install app/build/outputs/apk/debug/app-debug.apk

# Check installation
adb shell pm list packages | grep automation
```

### Debugging
```bash
# View logs
adb logcat | grep Automation

# Clear app data
adb shell pm clear com.aiautomation.assistant
```

---

## 🎓 Learning Path

### Beginner
1. Read README.md
2. Follow BUILD_GUIDE.md
3. Install on your device
4. Try learning a simple task

### Intermediate
1. Experiment with different apps
2. Learn complex multi-step tasks
3. Explore pattern recognition
4. Customize widget appearance

### Advanced
1. Read TECHNICAL_DOCUMENTATION.md
2. Modify ML algorithms
3. Add new action types
4. Implement custom triggers
5. Contribute improvements

---

## ✅ Quick Checklist

Before building:
- [ ] Android Studio installed
- [ ] Project folder opened
- [ ] Gradle synced successfully

Before installing:
- [ ] APK file created
- [ ] Transferred to Android device
- [ ] Android 13+ device ready

After installing:
- [ ] Accessibility service enabled
- [ ] Overlay permission granted
- [ ] Screen capture allowed
- [ ] Floating widget visible

---

## 🆘 Emergency Troubleshooting

**App won't install**
→ Enable "Unknown Sources" in Settings

**Service won't start**
→ Check all three permissions granted

**Widget disappeared**
→ Restart app from launcher

**App crashed**
→ Settings → Apps → AI Automation → Clear Data

**Still stuck?**
→ See detailed troubleshooting in README.md

---

## 🎉 You're Ready!

Pick your path:
- **Just want to use it?** → Follow "Using the App" above
- **Need to build it?** → See BUILD_GUIDE.md
- **Want to customize?** → See TECHNICAL_DOCUMENTATION.md

**Happy Automating! 🤖**
